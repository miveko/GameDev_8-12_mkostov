const Game = new Phaser.Game(800, 600, Phaser.AUTO, 'GameCanvas', { preload, create, update})

let myPlayer;

function preload() {
    // Game.load.image('tileset_1_terrain_2','Images/32x32_tileset_terrains_2.png')
    // Game.load.image('tileset_2_woodland','Images/32x32_tileset_woodland.png')
    // Game.load.tilemap('tilemap', 'MyMap.json', null, Phaser.Tilemap.TILED_JSON)
    Game.load.spritesheet('player','Images/ninja_walk.png', 264 / 4, 300 / 4)
    Game.load.image('background', 'Images/landscape.jpg')
}

function create() {
    // Game.stage.backgroundColor = '#ffffff'
    Game.add.sprite(0,0,'background')
    Game.world.setBounds(0,0, 1920, 1080)
  //  Game.scale.pageAlignHorizontally = true
  //  Game.add.text(Game.width / 2, Game.height / 2, 'Hello, World!', { font: '50px', align: 'center', fill: '#fff' }).anchor.setTo(0.5)
    //const map = Game.add.tilemap('tilemap')
    //map.addTilesetImage('32x32_tileset_terrains_2', 'tileset_1_terrain_2')
    //map.addTilesetImage('32x32_tileset_woodland', 'tileset_2_woodland')

    // map.createLayer(0) //map.createLayer("Tile Layer 1")
    // map.createLayer("Tile Layer 2")
    myPlayer = Game.add.sprite(Game.width / 2, Game.height / 2, "player")
    Game.physics.enable(myPlayer)
    //myPlayer.frame = 2

    Game.camera.follow(null, Phaser.Camera.FOLLOW_PLATFORMER, 0.5, 0.5)
    cursors = Game.input.keyboard.createCursorKeys()
    keyW = Game.input.keyboard.addKey(Phaser.Keyboard.W)
    keyS = Game.input.keyboard.addKey(Phaser.Keyboard.S)
    keyA = Game.input.keyboard.addKey(Phaser.Keyboard.A)
    keyD = Game.input.keyboard.addKey(Phaser.Keyboard.D)
}

function update() {
  if(cursors.up.isDown) {
    // myPlayer.body.velocity.y = -10;
    myPlayer.y -=10 
  } else if(cursors.down.isDown) {
    // myPlayer.body.velocity.y = 10;    
    myPlayer.y +=10 
  } else myPlayer.body.velocity.y = 0;

  if(cursors.right.isDown) {
    // myPlayer.body.velocity.x = 10;
    myPlayer.x +=10 
  } else if(cursors.left.isDown) {
    // myPlayer.body.velocity.x = -10;
    myPlayer.x -=10 
  } else myPlayer.body.velocity.x = 0;

  if(keyW.isDown) {
    Game.camera.y -= 10;
  } 
  if(keyS.isDown) {
    Game.camera.y = 10;
  } 
  if(keyA.isDown) {
    Game.camera.x -= 10;
  } 
  if(keyD.isDown) {
    Game.camera.x = 10;
  } 


  // console.log("velocity.x" + myPlayer.body.velocity.x);
  // console.log("velocity.y" + myPlayer.body.velocity.y);
}